# Perl入学式#7の資料

## slide_mojo

    $ cpanm Mojolicious Path::Class Text::Markdown
    $ morbo app.pl

ブラウザで「`http://localhost::3000`」にアクセスしてください。

スライドはカーソルの右で進み、左で戻ります。